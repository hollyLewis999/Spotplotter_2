from pathlib import Path
import os
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage,filedialog,font, Y, X, Frame, Scrollbar, BOTTOM, Label,messagebox, Scale, HORIZONTAL,BooleanVar, Checkbutton, CENTER,  DoubleVar, ROUND, LEFT, RIGHT
from tkinter import ttk
import tkinter as tk
import cv2
import numpy as np
from scipy.spatial import distance
from PIL import Image, ImageTk, ImageDraw
import copy
from functools import partial
import time
import math 
import sys
import json
import os
from datetime import datetime
from tkinter import Toplevel, Label
from PIL import Image, ImageTk
from Style import *
from PIL import ImageFont
DARK = "#092934"
LIGHT = "#FFFFFF"
COLORS = ["#D24C4A", "#D3784A", "#DFA24F", "#7DB46F", "#0F8660", "#46A2A2", "#7CC7BC", "#A9599C"] #https://coolors.co/d24c4a-d3784a-dfa24f-7db46f-0f8660-46a2a2-7cc7bc-a9599c
COLORS = ["#D24C4A", "#DFA24F", "#7DB46F", "#7CC7BC", "#46A2A2", "#0F8660", "#A9599C", "#D3784A"] #https://coolors.co/d24c4a-d3784a-dfa24f-7db46f-0f8660-46a2a2-7cc7bc-a9599c
CURRENTPLATEINDEX =-1
GRAY1 = "#F0F0F0"
GRAY2 = "#E0E0E0"
GRAY = "#B0B0B0"
FONT = "Microsoft New Tai Lue"

# d8888b. db       .d8b.  d888888b d88888b .d8888. 
# 88  `8D 88      d8' `8b `~~88~~' 88'     88'  YP 
# 88oodD' 88      88ooo88    88    88ooooo `8bo.   
# 88~~~   88      88~~~88    88    88~~~~~   `Y8b. 
# 88      88booo. 88   88    88    88.     db   8D 
# 88      Y88888P YP   YP    YP    Y88888P `8888Y' 



# def create_circular_slider(master, min_val, max_val, position, command=None, initial_value=None):
#     frame = Frame(master, width=300, height=70, bg=DARK)
#     frame.place(x=position[0], y=position[1])
#     canvas = Canvas(frame, width=300, height=70, bg=DARK, highlightthickness=0)
#     canvas.pack()
    
#     current_value = DoubleVar(value=min_val if initial_value is None else initial_value)
#     last_update_time = 0
#     update_interval = 100  # Update interval in milliseconds

#     def draw_slider(update_label=False):
#         canvas.delete("all")
#         filled_x = value_to_position(current_value.get())
#         canvas.create_line(10, 45, 290, 45, fill=GRAY, width=10, capstyle=ROUND)
#         canvas.create_line(10, 45, filled_x, 45, fill=LIGHT, width=10, capstyle=ROUND)
        
#         knob_x = value_to_position(current_value.get())
#         canvas.create_oval(knob_x-10, 35, knob_x+10, 55, fill=LIGHT, outline=DARK, tags="knob")
        
#         if update_label:
#             canvas.delete("value_text")
#             label_x = max(10, min(knob_x, 270))
#             canvas.create_text(label_x, 20, text=str(int(current_value.get())), 
#                                font=(FONT, 10, "bold"), fill=LIGHT, tags="value_text")

#     def value_to_position(value):
#         return (value - min_val) / (max_val - min_val) * 280 + 10

#     def position_to_value(x):
#         return (x - 10) / 280 * (max_val - min_val) + min_val

#     def on_drag(event):
#         nonlocal last_update_time
#         current_time = event.time
#         if 35 <= event.y <= 55:
#             new_value = position_to_value(event.x)
#             current_value.set(max(min_val, min(max_val, new_value)))
            
#             if current_time - last_update_time >= update_interval:
#                 draw_slider(update_label=True)
#                 last_update_time = current_time
#             else:
#                 draw_slider(update_label=False)
            
#             if command:
#                 command(int(current_value.get()))

#     def on_release(event):
#         draw_slider(update_label=True)
#         if command:
#             command(int(current_value.get()))

#     canvas.bind("<B1-Motion>", on_drag)
#     canvas.bind("<ButtonRelease-1>", on_release)

#     def set_value(value):
#         current_value.set(max(min_val, min(max_val, value)))
#         draw_slider(update_label=True)

#     draw_slider(update_label=True)
#     frame.set = set_value
#     frame.get = lambda: int(current_value.get())
#     return frame
        

def round_rectangle(canvas,x1, y1, x2, y2, radius=35, **kwargs):
        
    points = [x1+radius, y1,
              x1+radius, y1,
              x2-radius, y1,
              x2-radius, y1,
              x2, y1,
              x2, y1+radius,
              x2, y1+radius,
              x2, y2-radius,
              x2, y2-radius,
              x2, y2,
              x2-radius, y2,
              x2-radius, y2,
              x1+radius, y2,
              x1+radius, y2,
              x1, y2,
              x1, y2-radius,
              x1, y2-radius,
              x1, y1+radius,
              x1, y1+radius,
              x1, y1]

    return canvas.create_polygon(points, **kwargs, smooth=True)


def create_mode_switcher(control_frame, window):
    def switch_mode(new_mode):
        create_plate_designer(window, mode=new_mode)
   #bookmark 
    # Label for mode selection
    mode_label = Label(
        control_frame,
        text="Select Mode:",
        font=(FONT, 12, "bold"),
        fg=LIGHT,
        bg=DARK
    )
    mode_label.place(x=10, y=10)
    
    # Dropdown menu for mode selection
    mode_var = tk.StringVar(value=window.current_mode)  # Keep track of the current mode
    mode_dropdown = ttk.Combobox(
        control_frame,
        textvariable=mode_var,
        values=["A", "B"],
        state="readonly",
        font=(FONT, 11)
    )
    mode_dropdown.place(x=110, y=10, width=100)
    
    # Bind selection change to switch_mode function
    mode_dropdown.bind("<<ComboboxSelected>>", lambda event: switch_mode(mode_var.get()))

def create_controls(control_frame, window, mode):
    y_offset = 60
    spacing = 80
    label_width = 100  # Width for right-aligned labels
    
    # Function to create styled input row
    def create_input_row(label_text, variable, y_pos):
        # Right-aligned label
        label = Label(
            control_frame,
            text=label_text,
            font=(FONT, 12, 'bold'),
            fg=LIGHT,
            bg=DARK,
            width=10,
            anchor="e"
        )
        label.place(x=10, y=y_pos)
        
        # Custom rounded entry box
        entry_frame = RoundedEntry(control_frame, width=100, height=35)
        entry_frame.place(x=140, y=y_pos - 5)
        entry_frame.entry.config(textvariable=variable, font=(FONT, 11))
        
        return entry_frame.entry
    
    # Create input rows based on the mode
    create_input_row("Rows:", window.plate_layout['rows'], y_offset)
    create_input_row("Columns:", window.plate_layout['columns'], y_offset + spacing)
    
    if mode == "A":  # Show additional options in Mode A
        create_input_row("Strains:", window.plate_layout['strains'], y_offset + spacing * 2)
        create_input_row("X-Dilution:", window.plate_layout['x_dilution'], y_offset + spacing * 3)
        create_input_row("Y-Dilution:", window.plate_layout['y_dilution'], y_offset + spacing * 4)
        
        # Create checkbox for gap between strains
        checkbox = RoundedCheckbox(
            control_frame,
            text="Gap Between Strains",
            variable=window.plate_layout['gap_between_strains'],
            command=lambda: update_plate_display_layout_designer(window)
        )
        checkbox.place(x=20, y=y_offset + spacing * 5)
        checkbox.label.place(x=50, y=y_offset + spacing * 5)
    
    # Bind all variables to update function
    for var_name in ['rows', 'columns', 'strains', 'x_dilution', 'y_dilution']:
        window.plate_layout[var_name].trace_add(
            "write",
            lambda *args: update_plate_display_layout_designer(window)
        )




def create_plate_display(plate_frame, window):
    window.plate_canvas = tk.Canvas(
        plate_frame,
        bg=DARK,
        highlightthickness=0
    )
    window.plate_canvas.pack(expand=True, fill='both')
    window.plate_canvas.bind("<Button-1>", lambda event: handle_click(event, window))
    update_plate_display_layout_designer(window)

def update_plate_display_layout_designer(window):
    window.plate_canvas.delete('all')
    
    try:
        rows = max(1, window.plate_layout['rows'].get())
        cols = max(1, window.plate_layout['columns'].get())
        strains = max(1, window.plate_layout['strains'].get())
        x_dil = max(1, window.plate_layout['x_dilution'].get())
        y_dil = max(1, window.plate_layout['y_dilution'].get())
    except tk.TclError:
        return
        
    width = window.plate_canvas.winfo_width()
    height = window.plate_canvas.winfo_height()
    if width <= 1 or height <= 1:
        window.plate_canvas.after(100, lambda: update_plate_display_layout_designer(window))
        return
        
    margin = 50
    grid_width = width - 2 * margin
    grid_height = height - 2 * margin
    
    cols_per_strain = cols // strains
    total_cols = cols
    
    if window.plate_layout['gap_between_strains'].get():
        total_gaps = strains - 1
        total_cols = cols + total_gaps

    cell_width = grid_width / total_cols
    cell_height = grid_height / rows
    
    # Update strain positions
    current_col = 0
    window.plate_layout['strain_positions'] = {}
    
    for strain in range(strains):
        start_col = current_col
        end_col = start_col + cols_per_strain - 1
        window.plate_layout['strain_positions'][strain] = (start_col, end_col)
        current_col = end_col + 1
        if window.plate_layout['gap_between_strains'].get() and strain < strains - 1:
            current_col += 1
    
    
    draw_spots(window, strains, margin, cell_width, cell_height, x_dil, rows)


def draw_spots(window, strains, margin, cell_width, cell_height, x_dil, rows):
    for strain in range(strains):
        start_col, end_col = window.plate_layout['strain_positions'][strain]
        for col_offset in range(end_col - start_col + 1):
            actual_col = start_col + col_offset
            x_value = x_dil ** col_offset
            x_pos = margin + actual_col * cell_width + cell_width/2
            
            if window.current_mode =='A':
                window.plate_canvas.create_text(
                    x_pos,
                    margin - 20,
                    text=x_value,
                    fill=LIGHT,
                    font=(FONT, 8)
                )
            
            for row in range(rows):
                pos_key = f"{row}-{actual_col}"
                if pos_key not in window.plate_layout['removed_positions']:
                    x = margin + actual_col * cell_width + cell_width/2
                    y = margin + row * cell_height + cell_height/2
                    color = COLORS[strain % len(COLORS)]
                    
                    window.plate_canvas.create_oval(
                        x-10, y-10, x+10, y+10,
                        fill=color,
                        outline=color,
                        tags=(pos_key, "spot", f"strain_{strain}")
                    )

def handle_click(event, window):
    closest = window.plate_canvas.find_closest(event.x, event.y)
    tags = window.plate_canvas.gettags(closest)
    
    if tags and len(tags) > 1:
        pos_key = tags[0]
        if pos_key in window.plate_layout['removed_positions']:
            window.plate_layout['removed_positions'].remove(pos_key)
        else:
            window.plate_layout['removed_positions'].add(pos_key)
        update_plate_display_layout_designer(window)

def go_to_assignment_screen(window):
    valid_positions = {}
    for strain, (start_col, end_col) in window.plate_layout['strain_positions'].items():
        strain_positions = []
        for row in range(window.plate_layout['rows'].get()):
            for col in range(start_col, end_col + 1):
                pos_key = f"{row}-{col}"
                if pos_key not in window.plate_layout['removed_positions']:
                    strain_positions.append(pos_key)
        valid_positions[strain] = strain_positions

    layout_data = {
        'rows': window.plate_layout['rows'].get(),
        'columns': window.plate_layout['columns'].get(),
        'strains': window.plate_layout['strains'].get(),
        'x_dilution': window.plate_layout['x_dilution'].get(),
        'y_dilution': window.plate_layout['y_dilution'].get(),
        'gap_between_strains': window.plate_layout['gap_between_strains'].get(),
        'removed_positions': list(window.plate_layout['removed_positions']),
        'strain_positions': window.plate_layout['strain_positions'],
        'valid_positions': valid_positions
    }


    window.layout_data = layout_data
    create_strain_designer(window)



# .d8888. d888888b d8888b.  .d8b.  d888888b d8b   db .d8888. 
# 88'  YP `~~88~~' 88  `8D d8' `8b   `88'   888o  88 88'  YP 
# `8bo.      88    88oobY' 88ooo88    88    88V8o 88 `8bo.   
#   `Y8b.    88    88`8b   88~~~88    88    88 V8o88   `Y8b. 
# db   8D    88    88 `88. 88   88   .88.   88  V888 db   8D 
# `8888Y'    YP    88   YD YP   YP Y888888P VP   V8P `8888Y' 

def create_strain_designer(window):
    # Clear window
    for widget in window.winfo_children():
        widget.destroy()

    # Initialize window properties
    # Store all state as window attributes
    window.plates = []
    window.strains = []
    window.strain_colors = COLORS
    window.current_color_index = 0
    window.current_plate = 0
    window.strain_buttons = []
    window.position_labels = {i: chr(65 + i) for i in range(window.layout_data['strains'])}
    window.column_assignments = {}
    window.atc_var = tk.StringVar(value="") 
    # Create main canvas
    window.canvas = tk.Canvas(
        window,
        bg=LIGHT,
        height=1024,
        width=1440,
        bd=0,
        highlightthickness=0,
        relief="ridge"
    )
    window.canvas.place(x=0, y=0)

    # Load the image using PhotoImage (or Pillow for more formats)
    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png"))
    window.canvas.image_image_1 = image_image_1  # Keep a reference to prevent garbage collection

    # Place the image on the canvas
    image_1 = window.canvas.create_image(719.0, 57.0, image=image_image_1)

    # Main dark rectangles
    round_rectangle(window.canvas, 17.0, 168.0, 1100.0, 826.0, fill=DARK, outline="")
    round_rectangle(window.canvas, 1120.0, 168.0, 1422.0, 826.0, fill=DARK, outline="")

    # Create frames
    window.plate_frame = tk.Frame(window, bg=DARK)
    window.plate_frame.place(x=27, y=178, width=1070, height=638)

    window.control_frame = tk.Frame(window, bg=DARK)
    window.control_frame.place(x=1130, y=178, width=282, height=638)

    # Create subframes
    window.strains_frame = tk.Frame(window.control_frame, bg=DARK)
    window.strains_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

    window.bottom_frame = tk.Frame(window.control_frame, bg=DARK)
    window.bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
    setup_frames(window)



    create_rounded_button(
        canvas=window.canvas,
        text="Next",
        command=lambda:export_data(window),
        x=buttonPosX,
        y=buttonPosY
    )




def draw_plate(window, canvas, margin_left, margin_top, grid_width, grid_height):
    if CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        return
        
    plate = window.plates[CURRENTPLATEINDEX]
    
    # Calculate cell dimensions
    cols_per_strain = window.layout_data['columns'] // window.layout_data['strains']
    total_gaps = window.layout_data['strains'] - 1 if window.layout_data['gap_between_strains'] else 0
    total_width = window.layout_data['columns'] + total_gaps
    cell_width = grid_width / total_width
    cell_height = grid_height / window.layout_data['rows']

    # Draw position labels and spots
    current_x = margin_left
    for position_idx in range(window.layout_data['strains']):
        start_col, end_col = window.plate_layout['strain_positions'][position_idx]
        position_width = (end_col - start_col + 1) * cell_width

        # Find if this position is assigned to a strain
        assigned_strain = None
        for pos_key, assignment in plate.get('assignments', {}).items():
            row, col = map(int, pos_key.split('-'))
            if start_col <= col <= end_col:
                assigned_strain = assignment
                break

        # Draw position label
        label_text = assigned_strain if assigned_strain else f"Position {window.position_labels[position_idx]}"
        canvas.create_text(
            current_x + position_width/2,
            margin_top,
            text=label_text,
            font=(FONT, 16, 'bold'),
            fill=DARK
        )

        # Draw spots
        for col_offset in range(end_col - start_col + 1):
            col = start_col + col_offset
            x_pos = current_x + col_offset * cell_width + cell_width/2

            for row in range(window.layout_data['rows']):
                pos_key = f"{row}-{col}"
                if pos_key not in window.layout_data['removed_positions']:
                    y_pos = margin_top + row * cell_height + cell_height/2

                    # Determine spot color
                    spot_color = GRAY1
                    if pos_key in plate['assignments']:
                        strain = plate['assignments'][pos_key]
                        strain_index = window.strains.index(strain)
                        spot_color = window.strain_colors[strain_index]

                    # Draw spot
                    canvas.create_oval(
                        x_pos-8, y_pos-8, x_pos+8, y_pos+8,
                        fill=spot_color,
                        outline=spot_color,
                        tags=(pos_key, "spot")
                    )

        current_x += position_width

        if window.layout_data['gap_between_strains'] and position_idx < window.layout_data['strains'] - 1:
            current_x += cell_width



def update_plate_display(window):
    print(f"Total plates: {len(window.plates)}")
    
    if not window.plates:
        print("ERROR: No plates exist")
        return

    # Validate plate index
    if CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        print(f"ERROR: Invalid plate index {CURRENTPLATEINDEX}")
        return

    current_plate = window.plates[CURRENTPLATEINDEX]


    # Verify plate_canvas exists
    if not hasattr(window, 'plate_canvas'):
        print("ERROR: plate_canvas does not exist")
        return

    # Clear the canvas completely
    window.plate_canvas.delete('all')

    # Get canvas dimensions
    width = window.plate_canvas.winfo_width()
    height = window.plate_canvas.winfo_height()
    
    print(f"Canvas Dimensions: {width} x {height}")

    # If canvas is not properly sized, schedule a retry
    if width <= 1 or height <= 1:
        print("WARNING: Invalid canvas size, scheduling retry")
        window.plate_canvas.after(100, lambda: update_plate_display(window))
        return

    # Calculate dimensions
    margin_left = 30
    margin_right = 30
    margin_top = 70
    margin_bottom = 30

    grid_width = width - margin_left - margin_right
    grid_height = height - margin_top - margin_bottom

    # Print layout details for debugging
    print(f"Layout Details:")
    print(f"Rows: {window.layout_data['rows']}")
    print(f"Columns: {window.layout_data['columns']}")
    print(f"Strain Positions: {window.plate_layout['strain_positions']}")

    # Draw the plate
    try:
        draw_plate(window, window.plate_canvas, 
                   margin_left, margin_top, grid_width, grid_height)
    except Exception as e:
        print(f"ERROR in draw_plate: {e}")
        import traceback
        traceback.print_exc()

    # Update the plate display grid and header
    try:
        draw_plate_grid(window, width, height, margin_left, margin_right, margin_top, 
                        margin_bottom, grid_width, grid_height)
    except Exception as e:
        print(f"ERROR in draw_plate_grid: {e}")
        import traceback
        traceback.print_exc()

    print("======== PLATE DISPLAY UPDATE COMPLETE ========")



def delete_current_plate(window):
    global CURRENTPLATEINDEX
    if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        messagebox.showwarning("Warning", "No plate to delete")
        return
        
    if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete the current plate?"):
        # Remove the current plate
        window.plates.pop(CURRENTPLATEINDEX)
        
        # Adjust current plate index if necessary
        if CURRENTPLATEINDEX >= len(window.plates):
            CURRENTPLATEINDEX = max(len(window.plates) - 1, 0)
            
        # Reset column assignments
        window.column_assignments = {}
        
        # Update display
        # Update display
        if len(window.plates) == 0:
            window.plate_canvas.delete('all')
        else:    
            update_plate_display(window)

def clear_current_plate(window):
    if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        messagebox.showwarning("Warning", "No plate to clear")
        return
        
    if messagebox.askyesno("Confirm Clear", "Are you sure you want to clear all assignments from the current plate?"):
        # Clear all assignments from current plate
        window.plates[CURRENTPLATEINDEX]['assignments'] = {}
        window.column_assignments = {}
        
        # Update display
        update_plate_display(window)

def rename_current_plate(window):
    if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        messagebox.showwarning("Warning", "No plate to rename")
        return
        
    current_name = window.plates[CURRENTPLATEINDEX]['name']
    
    # Create rename dialog
    rename_dialog = tk.Toplevel(window)
    rename_dialog.title("Rename Plate")
    rename_dialog.geometry("300x120")
    rename_dialog.configure(bg=DARK)
    
    # Make dialog modal
    rename_dialog.transient(window)
    rename_dialog.grab_set()
    
    # Create and pack widgets
    tk.Label(
        rename_dialog,
        text="Enter new plate name:",
        font=(FONT, 12),
        bg=DARK,
        fg=LIGHT
    ).pack(pady=10)
    
    name_entry = ttk.Entry(rename_dialog, width=30)
    name_entry.insert(0, current_name)
    name_entry.pack(pady=5)
    
    def do_rename():
        new_name = name_entry.get().strip()
        if new_name:
            window.plates[CURRENTPLATEINDEX]['name'] = new_name
            update_plate_display(window)
            rename_dialog.destroy()
    
    button_frame = tk.Frame(rename_dialog, bg=DARK)
    button_frame.pack(pady=10)
    
    tk.Button(
        button_frame,
        text="Cancel",
        command=rename_dialog.destroy,
        font=(FONT, 10),
        bg=LIGHT,
        fg=DARK
    ).pack(side=tk.LEFT, padx=5)
    
    tk.Button(
        button_frame,
        text="Rename",
        command=do_rename,
        font=(FONT, 10),
        bg=LIGHT,
        fg=DARK
    ).pack(side=tk.LEFT, padx=5)
    
    # Center the dialog on the window
    rename_dialog.update_idletasks()
    window_width = window.winfo_width()
    window_height = window.winfo_height()
    dialog_width = rename_dialog.winfo_width()
    dialog_height = rename_dialog.winfo_height()
    x = window.winfo_x() + (window_width - dialog_width) // 2
    y = window.winfo_y() + (window_height - dialog_height) // 2
    rename_dialog.geometry(f"+{x}+{y}")


def create_strain_controls(window):
    if window.current_mode =='A':
        # "Add a strain" header
        strain_header = tk.Label(window.control_frame, text="Add a Strain", font=(FONT, 14, 'bold'), fg=LIGHT, bg=DARK)
        strain_header.pack(pady=(10, 5))
        
        # Strain name frame
        strain_frame = tk.Frame(window.control_frame, bg=DARK)
        strain_frame.pack(fill=tk.X, padx=10)
        
        # Initialize strains attribute if not exists
        if not hasattr(window, 'strains'):
            window.strains = []
        
        # Strain entry
        window.strain_entry = ttk.Entry(strain_frame, width=25)
        window.strain_entry.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 5))
        
        # Add strain button (now a + button)
        add_strain_btn = tk.Button(
            strain_frame,
            text="+",
            command=lambda: add_strain(window),
            font=(FONT, 10),
            bg=LIGHT,
            fg=DARK,
            width=3
        )
        add_strain_btn.pack(side=tk.RIGHT)
        
        # Blank space for added strains
        window.strain_list_frame = tk.Frame(window.control_frame, bg=DARK)
        window.strain_list_frame.pack(fill=tk.X, padx=10, pady=(5, 20))

def add_strain(window):
    strain = window.strain_entry.get().strip()
    if strain and strain not in window.strains:
        if len(window.strains) >= len(window.strain_colors):
            messagebox.showwarning("Warning", "Maximum number of strains reached")
            return
        
        window.strains.append(strain)
        window.strain_entry.delete(0, tk.END)
        
        # Create strain frame within strain_list_frame instead of strains_frame
        strain_frame = tk.Frame(window.strain_list_frame, bg=DARK)
        strain_frame.pack(fill=tk.X, pady=2)
        
        color_indicator = tk.Label(
            strain_frame,
            bg=window.strain_colors[len(window.strains)-1],
            width=2,
            height=1
        )
        color_indicator.pack(side=tk.LEFT, padx=(0, 5))
        
        strain_label = tk.Label(
            strain_frame,
            text=strain,
            font=(FONT, 10),
            fg=LIGHT,
            bg=DARK
        )
        strain_label.pack(side=tk.LEFT, expand=True, anchor='w')
        
        assign_btn = tk.Button(
            strain_frame,
            text="Assign",
            command=lambda s=strain: assign_strain_to_group(window, s),
            font=(FONT, 8),
            bg=LIGHT,
            fg=DARK
        )
        assign_btn.pack(side=tk.RIGHT)
        
        window.strain_buttons.append((strain_label, assign_btn))
        update_plate_display(window)

        
def create_plate_canvas(window):
    window.plate_canvas = tk.Canvas(
        window.plate_frame,
        bg=DARK,
        highlightthickness=0
    )
    window.plate_canvas.pack(expand=True, fill='both')
    window.plate_canvas.bind("<Button-3>", lambda e: unselect_position(window, window.current_plate, e))
    
    # Force initial update with current plate index
    window.plate_canvas.after(100, lambda: update_plate_display(window))


def add_plate(window):
    global CURRENTPLATEINDEX
    name = window.plate_entry.get().strip()
    if name:
        additive_name = window.additive_entry.get().strip() if window.additive_var.get() else None
        new_plate = {
            'name': name,
            'additive': additive_name,
            'assignments': {},
            'column_assignments': {}
        }
        window.plates.append(new_plate)
        window.plate_entry.delete(0, tk.END)
        window.current_plate = len(window.plates) - 1
        window.column_assignments = {}
        CURRENTPLATEINDEX = (len(window.plates) - 1)
        update_plate_display(window)
        print(f"Plate added. Total plates: {len(window.plates)}")

def unselect_position(window, event):
    if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        return
        
    clicked_items = window.plate_canvas.find_closest(event.x, event.y)
    if not clicked_items:
        return
        
    clicked_item = clicked_items[0]
    tags = window.plate_canvas.gettags(clicked_item)
    
    if "spot" in tags:
        pos_key = tags[0]
        row, col = map(int, pos_key.split('-'))
        
        for position_key, strain in list(window.column_assignments.items()):
            start, end = map(int, position_key.split('-'))
            if start <= col <= end:
                del window.column_assignments[position_key]
                
        plate = window.plates[CURRENTPLATEINDEX]
        for row_idx in range(window.layout_data['rows']):
            key = f"{row_idx}-{col}"
            if key in plate['assignments']:
                del plate['assignments'][key]
        
        update_plate_display(window)



def update_strain_menu(window):
    # Remove existing menu if it exists
    for widget in window.control_frame.winfo_children():
        if isinstance(widget, tk.OptionMenu):
            widget.destroy()

    if window.strains:
        selected_strain = tk.StringVar(value=window.strains[0])
        menu = tk.OptionMenu(
            window.control_frame,
            selected_strain,
            *window.strains
        )
        menu.configure(font=(FONT, 10), bg=LIGHT, fg=DARK)
        menu.grid(row=3, column=2, padx=20, pady=10)


def assign_strain_to_group(window, strain):
    if window.current_mode =='A':
        if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
            messagebox.showwarning("Warning", "Please create a plate first")
            return

        # Create menu of available positions
        available_positions = []
        for strain_idx, (start_col, end_col) in window.plate_layout['strain_positions'].items():
            position_key = f"{start_col}-{end_col}"
            if position_key not in window.column_assignments:
                available_positions.append((strain_idx, start_col, end_col))

        if available_positions:
            strain_location_menu = tk.Menu(window, tearoff=0)
            for strain_idx, start_col, end_col in available_positions:
                label = f"Position {window.position_labels[strain_idx]}"
                strain_location_menu.add_command(
                    label=label,
                    command=lambda s=start_col, e=end_col, idx=strain_idx: 
                        assign_strain_to_columns(window, strain, s, e, idx)
                )

            try:
                strain_location_menu.tk_popup(window.winfo_pointerx(), window.winfo_pointery())
            finally:
                strain_location_menu.grab_release()
        else:
            messagebox.showwarning("Warning", "All positions are already assigned.")


def assign_strain_to_columns(window, strain, start_col, end_col, position_idx):
    if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        return
        
    plate = window.plates[CURRENTPLATEINDEX]
    position_key = f"{start_col}-{end_col}"
    
    # Check if columns are already assigned
    for existing_key in list(window.column_assignments.keys()):
        existing_start, existing_end = map(int, existing_key.split('-'))
        if (start_col <= existing_end and end_col >= existing_start):
            return
            
    window.column_assignments[position_key] = {
        'strain': strain,
        'position': window.position_labels[position_idx],
        'position_idx': position_idx
    }
    
    # Assign spots to strain
    for row in range(window.layout_data['rows']):
        for col in range(start_col, end_col + 1):
            pos_key = f"{row}-{col}"
            if pos_key not in window.layout_data['removed_positions']:
                plate['assignments'][pos_key] = strain
                
    update_plate_display(window)


def draw_plate_grid(window, width, height, margin_left, margin_right, margin_top, 
                   margin_bottom, grid_width, grid_height):
    if not window.plates or CURRENTPLATEINDEX < 0 or CURRENTPLATEINDEX >= len(window.plates):
        return
        
    plate = window.plates[CURRENTPLATEINDEX]
    num_strains = window.layout_data['strains']

    # Draw plate header
    additive_display = f"( Additive: {plate['additive']})" if plate.get('additive') is not None else ''
    
    # Draw plate header with corrected syntax
    window.plate_canvas.create_text(
        width // 2,
        20,
        text=f"Current Plate: {CURRENTPLATEINDEX + 1} - {plate['name']}{additive_display}",
        fill=LIGHT,
        font=(FONT, 16, 'bold')
    )
    
    # Calculate cell dimensions
    cols_per_strain = window.layout_data['columns'] // num_strains
    total_gaps = num_strains - 1 if window.layout_data['gap_between_strains'] else 0
    total_width = window.layout_data['columns'] + total_gaps
    cell_width = grid_width / total_width
    cell_height = grid_height / window.layout_data['rows']
    
    draw_positions_and_spots(window, margin_left, margin_top, 
                           cell_width, cell_height, num_strains)    
def draw_positions_and_spots(window, margin_left, margin_top, 
                           cell_width, cell_height, num_strains):
    plate = window.plates[CURRENTPLATEINDEX]                  
    current_x = margin_left
    for position_idx in range(num_strains):
        start_col, end_col = window.plate_layout['strain_positions'][position_idx]
        position_width = (end_col - start_col + 1) * cell_width
        
        # Find assigned strain from the current plate's assignments
        assigned_strain = None
        for pos_key in plate.get('assignments', {}):
            row, col = map(int, pos_key.split('-'))
            if start_col <= col <= end_col:
                assigned_strain = plate['assignments'][pos_key]
                break
        
        if window.current_mode =='A':
            # Draw position label
            label_text = assigned_strain if assigned_strain else f"Position {window.position_labels[position_idx]}"
            window.plate_canvas.create_text(
                current_x + position_width/2,
                margin_top,
                text=label_text,
                font=(FONT, 16, 'bold'),
                fill=LIGHT
            )

        
        current_x += position_width
        if window.layout_data['gap_between_strains'] and position_idx < num_strains - 1:
            current_x += cell_width

def create_plate_info(window, plate, rows, cols, unordered_quantifications,
                      strains, column_indexes):
    # Create preview image
    preview_image = create_plate_preview_image(window, plate)
    
    return {
        'mode': window.current_mode,
        'filename': plate['name'],
        'additive': plate.get('additive', None),
        'dilutions': [],
        'unorderedquantifications': unordered_quantifications,
        'IMGcontours': None,
        'IMGbinary': None,
        'IMGbinaryAutomatic':None,
        'IMGToolUsage': None,
        'IMGgrid': None,
        'threshold': 0,
        'smallArea': 0,
        'blocksize': 0,
        'strains': strains,
        'column_indexes': [list(indexes) for indexes in column_indexes],
        'normalisation_values': [],
        'strain_positions': window.plate_layout['strain_positions'],
        'split_quantifications':[],
        'ordered_quantifications':[],
        'removed_positions': list(window.plate_layout['removed_positions']),
        'layout': {
            'rows': rows,
            'columns': cols,
            'x_dilution': window.layout_data['x_dilution'],
            'y_dilution': window.layout_data['y_dilution'],
            'gap_between_strains': window.layout_data['gap_between_strains'],
            'IMGPreview': preview_image  # Store the base64 encoded image
        }
    }
    
def create_plate_preview_image(window, plate, width=1600, height=1200):
    """
    Creates a preview image for a single plate and returns it as a base64 string.
    Uses PIL for direct drawing instead of taking screenshots.
    """
    import io
    import base64
    from PIL import Image, ImageDraw, ImageFont
    
    # Create new image with white background
    margin = 20
    img_width = width - 40
    img_height = height - 60
    image = Image.new('RGB', (img_width, img_height), 'white')
    draw = ImageDraw.Draw(image)
    
    # Calculate dimensions
    grid_width = img_width - 2 * margin
    grid_height = img_height - 2 * margin
    
    cols_per_strain = window.layout_data['columns'] // window.layout_data['strains']
    total_gaps = window.layout_data['strains'] - 1 if window.layout_data['gap_between_strains'] else 0
    total_width = window.layout_data['columns'] + total_gaps
    cell_width = grid_width / total_width
    cell_height = grid_height / window.layout_data['rows']
    
    # Try to load fonts (fallback to default if not available)
    try:
        # Try to load Helvetica Bold
        label_font = ImageFont.truetype("arial.ttf", 45)
        strain_font = ImageFont.truetype("arial.ttf", 45)
    except IOError:
        try:
            # Fallback to default font if Helvetica-Bold is not found
            label_font = ImageFont.load_default()
            strain_font = ImageFont.load_default()
            print("Helvetica Bold not found, using default font")
        except:
            print("Failed to load default font")
    
    # Draw strain sections and labels
    current_x = margin
    for position_idx in range(window.layout_data['strains']):
        start_col, end_col = window.plate_layout['strain_positions'][position_idx]
        position_width = (end_col - start_col + 1) * cell_width
        
        # Find strain assignment for this section
        assigned_strain = None
        for pos_key, assignment in plate.get('assignments', {}).items():
            row, col = map(int, pos_key.split('-'))
            if start_col <= col <= end_col:
                assigned_strain = assignment 
                break
        
        # Draw strain label if assigned
        if assigned_strain:
            text_width = draw.textlength(assigned_strain, font=strain_font)
            draw.text(
                (current_x + position_width/2 - text_width/2, margin),
                assigned_strain,
                font=strain_font,
                fill='black'
            )
        
        # Draw spots
        for col_offset in range(end_col - start_col + 1):
            col = start_col + col_offset
            x_pos = int(current_x + col_offset * cell_width + cell_width/2)
            
            for row in range(window.layout_data['rows']):
                pos_key = f"{row}-{col}"
                if pos_key not in window.plate_layout['removed_positions']:
                    y_pos = int(margin + row * cell_height + cell_height/2)
                    
                    # Determine spot color
                    spot_color = GRAY1  # Your default gray color
                    if pos_key in plate['assignments']:
                        strain = plate['assignments'][pos_key]
                        strain_index = window.strains.index(strain)
                        spot_color = window.strain_colors[strain_index]
                    
                    # Draw spot (circle)
                    size = 16
                    draw.ellipse(
                        [x_pos-size, y_pos-size, x_pos+size, y_pos+size],
                        fill=spot_color,
                        outline=spot_color
                    )
        
        # Update x position for next group
        current_x += position_width
        
        # Add gap after each position except the last one
        if window.layout_data['gap_between_strains'] and position_idx < window.layout_data['strains'] - 1:
            current_x += cell_width
    
    # Convert to base64
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    img_str = base64.b64encode(buffer.getvalue()).decode()
    
    return img_str

def preview_all_plates(window):
    if not window.plates:
        messagebox.showinfo("Info", "No plates to preview")
        return
    
    preview_window = tk.Toplevel(window)
    preview_window.title("SpotPlotter: All Plates Preview")
    preview_window.geometry("1200x800")
    preview_window.iconbitmap(r'C:\Users\ThinkPad\Documents\AA ACADEMIC 2024\Thesis\GUI\ICONS\ICON.ico')

    main_frame = tk.Frame(preview_window, bg=DARK)
    main_frame.pack(fill='both', expand=True)
    canvas = tk.Canvas(main_frame, bg=DARK, highlightthickness=0)
    scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, bg=DARK)
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    plates_per_row = 2
    plate_width = 400
    plate_height = 300
    margin = 20

    for i, plate in enumerate(window.plates):
        row = i // plates_per_row
        col = i % plates_per_row
        plate_frame = tk.Frame(scrollable_frame, bg=LIGHT, bd=2, relief='raised')
        plate_frame.grid(row=row, column=col, padx=margin, pady=margin)
        
        # Create header with plate name
        header = tk.Label(
            plate_frame,
            text=f"{plate.get('name', 'Unnamed')}",
            font=(FONT, 12, 'bold'),
            bg=LIGHT
        )
        header.pack(pady=(5, 0))
        
        # Add additive information or "Control"
        additive_text = plate.get('additive', 'Control')
        additive_label = tk.Label(
            plate_frame,
            text=f"Additive: {additive_text}",
            font=(FONT, 10, 'italic'),
            bg=LIGHT,
            fg='#666666'
        )
        additive_label.pack(pady=(0, 5))

        plate_canvas = tk.Canvas(
            plate_frame,
            width=plate_width - 40,
            height=plate_height - 60,
            bg=LIGHT,
            highlightthickness=1
        )
        plate_canvas.pack(padx=10, pady=5)
        draw_plate_preview(window, plate_canvas, plate)

    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

def draw_plate_preview(window, canvas, plate):
    # Calculate cell dimensions
    canvas_width = canvas.winfo_reqwidth()
    canvas_height = canvas.winfo_reqheight()
   
    margin = 20
    grid_width = canvas_width - 2 * margin
    grid_height = canvas_height - 2 * margin
   
    # Calculate dimensions considering gaps
    cols_per_strain = window.layout_data['columns'] // window.layout_data['strains']
    total_gaps = window.layout_data['strains'] - 1 if window.layout_data['gap_between_strains'] else 0
    total_width = window.layout_data['columns'] + total_gaps
    cell_width = grid_width / total_width
    cell_height = grid_height / window.layout_data['rows']
    # Draw strain sections and labels
    current_x = margin
    for position_idx in range(window.layout_data['strains']):
        start_col, end_col = window.plate_layout['strain_positions'][position_idx]
        position_width = (end_col - start_col + 1) * cell_width
       
        # Find strain assignment for this section
        assigned_strain = None
        for pos_key, assignment in plate.get('assignments', {}).items():
            row, col = map(int, pos_key.split('-'))
            if start_col <= col <= end_col:
                assigned_strain = assignment
                break
       
        if window.current_mode =='A':
            # Draw position label
            position_label = f"Position {window.position_labels[position_idx]}"
            canvas.create_text(
                current_x + position_width/2,
                margin,
                text=position_label,
                font=(FONT, 12, 'bold'),
                fill=DARK,
                anchor='s',


            )
       
        # # Draw strain label if assigned - moved higher up
        # if assigned_strain:
        #     canvas.create_text(
        #         current_x + position_width/2,
        #         margin - 5,  # Moved higher, above the spot area
        #         text=assigned_strain,
        #         font=(FONT, 9),
        #         fill=DARK,
        #         anchor='s'  # Changed to 's' (south) to align bottom of text with this point
        #     )
       
        # Draw spots
        for col_offset in range(end_col - start_col + 1):
            col = start_col + col_offset
            x_pos = current_x + col_offset * cell_width + cell_width/2
           
            for row in range(window.layout_data['rows']):
                pos_key = f"{row}-{col}"
                if pos_key not in window.plate_layout['removed_positions']:
                    y_pos = margin + row * cell_height + cell_height/2
                   
                    # Determine spot color based on strain assignment
                    spot_color = GRAY1
                    if pos_key in plate['assignments']:
                        strain = plate['assignments'][pos_key]
                        strain_index = window.strains.index(strain)
                        spot_color = window.strain_colors[strain_index]
                   
                    # Draw spot
                    canvas.create_oval(
                        x_pos-8, y_pos-8, x_pos+8, y_pos+8,
                        fill=spot_color,
                        outline=spot_color
                    )
       
        # Update x position for next group
        current_x += position_width
       
        # Add gap after each position except the last one
        if window.layout_data['gap_between_strains'] and position_idx < window.layout_data['strains'] - 1:
            current_x += cell_width



def prev_plate(window):
    global CURRENTPLATEINDEX
    if window.plates and window.current_plate > 0:
        # Clear current display
        window.plate_canvas.delete('all')
        CURRENTPLATEINDEX = CURRENTPLATEINDEX -1
        # Update current plate index
        window.current_plate -= 1
        new_plate = window.plates[window.current_plate]
        
        # Update entry fields
        window.plate_entry.delete(0, tk.END)
        window.plate_entry.insert(0, new_plate['name'])
        window.atc_var.set(new_plate.get('atc', ''))
        
        # Update display with new plate index
        update_plate_display(window)
        window.plate_canvas.focus_set()
    else:
        print("Cannot go to previous plate")

def next_plate(window):
    global CURRENTPLATEINDEX
    if window.plates and window.current_plate < len(window.plates) - 1:
        # Clear current display
        CURRENTPLATEINDEX = CURRENTPLATEINDEX +1
        window.plate_canvas.delete('all')
        
        # Update current plate index
        window.current_plate += 1
        new_plate = window.plates[window.current_plate]
        
        # Update entry fields
        window.plate_entry.delete(0, tk.END)
        window.plate_entry.insert(0, new_plate['name'])
        window.atc_var.set(new_plate.get('atc', ''))
        
        # Update display with new plate index
        update_plate_display(window)
        window.plate_canvas.focus_set()
    else:
        print("Cannot go to next plate")

def export_data(window):
    """
    Export plate data and allow the user to choose the file location and name.
    Returns: List of plate info and saves to a user-specified JSON file.
    """
    all_plate_info = []
   
    for plate in window.plates:
        rows = window.layout_data['rows']
        cols = window.layout_data['columns']
        unordered_quantifications = [[0 for _ in range(cols)] for _ in range(rows)]
       
        ordered_assignments = []
        plate_assignments = plate.get('assignments', {})
       
        # Process assignments in order of positions
        for pos_idx in range(window.layout_data['strains']):
            start_col, end_col = window.plate_layout['strain_positions'][pos_idx]
           
            strain = None
            for col in range(start_col, end_col + 1):
                test_key = f"0-{col}"
                if test_key in plate_assignments:
                    strain = plate_assignments[test_key]
                    break
           
            if strain:
                ordered_assignments.append({
                    'strain': strain,
                    'columns': list(range(start_col, end_col + 1))
                })
       
        strains = [assignment['strain'] for assignment in ordered_assignments]
        column_indexes = [assignment['columns'] for assignment in ordered_assignments]
       
        plate_info = create_plate_info(window, plate, rows, cols, unordered_quantifications,
                                     strains, column_indexes)
        all_plate_info.append(plate_info)
   
    # Ask the user for the file name and location
    filename = filedialog.asksaveasfilename(
        title="Save Plate Data",
        defaultextension=".json",
        filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
    )
   
    # Check if the user canceled the file dialog
    if not filename:
        print("Export canceled by the user.")
        return None
        
    save_to_file(all_plate_info, filename)
    print(f"Data exported successfully to {filename}")
    
    window.all_plate_info = all_plate_info
    create_titleFrame(window)
    return all_plate_info

def save_to_file(data, filename):
    """
    Save plate data to a JSON file.
    """
    try:
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error saving file: {str(e)}")
        raise

def load_from_file(filename):
    """
    Load plate data from a JSON file
    Returns: List of plate info loaded from file
    """
    try:
        if not os.path.exists(filename):
            raise FileNotFoundError(f"File not found: {filename}")
            
        with open(filename, 'r') as f:
            data = json.load(f)
            print(f"Data loaded successfully from {filename}")
            return data
            
    except Exception as e:
        print(f"Error loading file: {str(e)}")
        raise

def get_available_data_files():
    """
    Get list of available plate data files in current directory
    Returns: List of filenames matching the plate data pattern
    """
    files = [f for f in os.listdir('.') if f.startswith('plate_data_') and f.endswith('.json')]
    return sorted(files, reverse=True)


def create_plate_controls(window):
    # Main controls container at the top
    controls_container = tk.Frame(window.control_frame, bg=DARK)
    controls_container.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)
    
    # "Add a plate" header
    plate_header = tk.Label(
        controls_container, 
        text="Add a Plate", 
        font=(FONT, 14, 'bold'), 
        fg=LIGHT, 
        bg=DARK
    )
    plate_header.pack(pady=(0, 10))

    # Plate name entry frame

    # Additive controls
    window.additive_var = tk.BooleanVar(value=False)
    additive_frame = tk.Frame(controls_container, bg=DARK)
    additive_frame.pack(fill=tk.X, pady=(0, 10))
    
    additive_check = RoundedCheckbox(
        additive_frame,
        text="Additive",
        variable=window.additive_var,
        command=lambda: toggle_additive_entry(window)
    )
    additive_check.pack(side=tk.LEFT)
    additive_check.label.pack(side=tk.LEFT, padx=(5, 0))
    
    window.additive_entry = RoundedEntry(
        additive_frame,
        width=150,
        height=35,
        state=tk.DISABLED
    )
    window.additive_entry.pack(side=tk.RIGHT)

    name_frame = tk.Frame(controls_container, bg=DARK)
    name_frame.pack(fill=tk.X, pady=(0, 10))
    
    window.plate_entry = RoundedEntry(
        name_frame,
        width=200,
        height=35
    )
    window.plate_entry.pack(side=tk.LEFT, expand=True, padx=(0, 5))
    
    add_plate_btn = tk.Button(
        name_frame,
        text="+",
        command=lambda: add_plate(window),
        font=(FONT, 12, 'bold'),
        bg=LIGHT,
        fg=DARK,
        width=3,
        height=1,
        relief="flat",
        bd=0
    )
    add_plate_btn.pack(side=tk.RIGHT)

    

    # Plate management buttons
    buttons_frame = tk.Frame(controls_container, bg=DARK)
    buttons_frame.pack(fill=tk.X, pady=(10, 0))
    
    # Create a consistent button style
    def create_control_button(parent, text, command):
        return tk.Button(
            parent,
            text=text,
            command=command,
            font=(FONT, 11),
            bg=LIGHT,
            fg=DARK,
            relief="flat",
            bd=0,
            padx=15,
            pady=5,
            cursor="hand2"
        )
    
    delete_btn = create_control_button(
        buttons_frame,
        "Delete",
        lambda: delete_current_plate(window)
    )
    delete_btn.pack(side=tk.LEFT, expand=True, padx=2)
    
    clear_btn = create_control_button(
        buttons_frame,
        "Clear",
        lambda: clear_current_plate(window)
    )
    clear_btn.pack(side=tk.LEFT, expand=True, padx=2)
    
    rename_btn = create_control_button(
        buttons_frame,
        "Rename",
        lambda: rename_current_plate(window)
    )
    rename_btn.pack(side=tk.LEFT, expand=True, padx=2)

def toggle_additive_entry(window):
    if window.additive_var.get():
        window.additive_entry.entry.config(state=tk.NORMAL)
    else:
        window.additive_entry.entry.config(state=tk.DISABLED)
        window.additive_entry.entry.delete(0, tk.END)

def create_navigation_controls(window):
    # Navigation controls at the bottom
    nav_container = tk.Frame(window.control_frame, bg=DARK)
    nav_container.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
    
    def create_nav_button(parent, text, command):
        return tk.Button(
            parent,
            text=text,
            command=command,
            font=(FONT, 11),
            bg=LIGHT,
            fg=DARK,
            relief="flat",
            bd=0,
            padx=15,
            pady=5,
            cursor="hand2"
        )
    
    # Navigation buttons
    nav_frame = tk.Frame(nav_container, bg=DARK)
    nav_frame.pack(fill=tk.X, pady=(0, 10))
    
    prev_plate_btn = create_nav_button(
        nav_frame,
        "Previous Plate",
        lambda: prev_plate(window)
    )
    prev_plate_btn.pack(side=tk.LEFT, expand=True, padx=2)
    
    next_plate_btn = create_nav_button(
        nav_frame,
        "Next Plate",
        lambda: next_plate(window)
    )
    next_plate_btn.pack(side=tk.LEFT, expand=True, padx=2)
    
    # Action buttons
    action_frame = tk.Frame(nav_container, bg=DARK)
    action_frame.pack(fill=tk.X)
    
    preview_btn = create_nav_button(
        action_frame,
        "Preview All Plates",
        lambda: preview_all_plates(window)
    )
    preview_btn.pack(side=tk.LEFT, expand=True, padx=2)
    


def setup_frames(window):
    # Main frames
    window.plate_frame = tk.Frame(window, bg=DARK)
    window.plate_frame.place(x=27, y=178, width=1070, height=638)
    
    window.control_frame = tk.Frame(window, bg=DARK)
    window.control_frame.place(x=1130, y=178, width=282, height=638)
    
    # Create three subframes within the control frame
    window.plate_controls_frame = tk.Frame(window.control_frame, bg=DARK)
    window.plate_controls_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)
    
    # window.strains_frame = tk.Frame(window.control_frame, bg=DARK)
    # window.strains_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)
    
    # # Create a frame for strain input and list
    # window.strain_input_frame = tk.Frame(window.strains_frame, bg=DARK)
    # window.strain_input_frame.pack(fill=tk.X, pady=(0, 10))
    
    # # Strain input elements
    # strain_label = tk.Label(
    #     window.strain_input_frame, 
    #     text="Add Strain", 
    #     font=(FONT, 14, 'bold'), 
    #     fg=LIGHT, 
    #     bg=DARK
    # )
    # strain_label.pack(pady=(0, 10))
    
    # strain_entry_frame = tk.Frame(window.strain_input_frame, bg=DARK)
    # strain_entry_frame.pack(fill=tk.X)
    
    # window.strain_entry = RoundedEntry(
    #     strain_entry_frame,
    #     width=200,
    #     height=35
    # )
    # window.strain_entry.pack(side=tk.LEFT, expand=True, padx=(0, 5))
    
    # # add_strain_btn = tk.Button(
    # #     strain_entry_frame,
    # #     text="+",
    # #     command=lambda: add_strain(window),
    # #     font=(FONT, 12, 'bold'),
    # #     bg=LIGHT,
    # #     fg=DARK,
    # #     width=3,
    # #     height=1,
    # #     relief="flat",
    # #     bd=0
    # # )
    # # add_strain_btn.pack(side=tk.RIGHT)
    
    # # Frame for strain list (where strains will be added)
    # window.strain_list_frame = tk.Frame(window.strains_frame, bg=DARK)
    # window.strain_list_frame.pack(fill=tk.X, padx=10, pady=(5, 20))
    
    window.bottom_frame = tk.Frame(window.control_frame, bg=DARK)
    window.bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
    
    # Populate the frames
    create_plate_controls(window)
    create_strain_controls(window)  # You'll need to define this function
    create_navigation_controls(window)
    create_plate_canvas(window)

class RoundedEntry(tk.Frame):
    def __init__(self, parent, width=100, height=35, corner_radius=10, **kwargs):
        super().__init__(parent, bg=DARK)
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Create rounded canvas background
        self.canvas = tk.Canvas(
            self,
            width=width,
            height=height,
            bg=DARK,
            highlightthickness=0
        )
        self.canvas.grid(row=0, column=0)
        
        # Draw rounded rectangle
        self.canvas.create_rounded_rectangle = lambda x1, y1, x2, y2, r, **kwargs: self.canvas.create_polygon(
            x1+r, y1,
            x1+r, y1,
            x2-r, y1,
            x2-r, y1,
            x2, y1,
            x2, y1+r,
            x2, y2-r,
            x2, y2,
            x2-r, y2,
            x1+r, y2,
            x1, y2,
            x1, y2-r,
            x1, y1+r,
            x1, y1,
            smooth=True,
            **kwargs
        )
        
        bg_box = self.canvas.create_rounded_rectangle(
            2, 2, width-2, height-2,
            corner_radius,
            fill="white",
            outline="#cccccc"
        )
        
        self.entry = tk.Entry(
            self,
            bg="white",
            bd=0,
            highlightthickness=0,
            **kwargs
        )
        self.entry.place(
            x=10,
            y=height//2,
            width=width-20,
            anchor="w"
        )

    # Add these delegate methods
    def get(self):
        """Delegate get() to the internal entry widget"""
        return self.entry.get()
    
    def delete(self, first, last=None):
        """Delegate delete() to the internal entry widget"""
        return self.entry.delete(first, last)
    
    def insert(self, index, string):
        """Delegate insert() to the internal entry widget"""
        return self.entry.insert(index, string)

class RoundedCheckbox(tk.Canvas):
    def __init__(self, parent, text="", command=None, variable=None, **kwargs):
        super().__init__(
            parent,
            width=24,
            height=24,
            highlightthickness=0,
            bg=DARK,
            **kwargs
        )
        self.variable = variable
        self.command = command
        
        # Create the rounded rectangle for the checkbox
        self.box = self.create_rounded_rectangle(
            2, 2, 22, 22,
            5,  # corner radius
            outline="#cccccc",
            fill="white",
            width=2
        )
        
        # Create the checkmark (hidden initially)
        self.checkmark = self.create_line(
            6, 12, 10, 16, 18, 8,
            fill=DARK,
            width=3,
            state="hidden"
        )
        
        # Bind click event
        self.bind("<Button-1>", self.toggle)
        
        # Create label
        self.label = Label(
            parent,
            text=text,
            bg=DARK,
            fg=LIGHT,
            font=(FONT, 12)
        )
        
    def create_rounded_rectangle(self, x1, y1, x2, y2, radius, **kwargs):
        points = [
            x1+radius, y1,
            x2-radius, y1,
            x2, y1,
            x2, y1+radius,
            x2, y2-radius,
            x2, y2,
            x2-radius, y2,
            x1+radius, y2,
            x1, y2,
            x1, y2-radius,
            x1, y1+radius,
            x1, y1
        ]
        return self.create_polygon(points, smooth=True, **kwargs)
    
    def toggle(self, event=None):
        if self.variable:
            self.variable.set(not self.variable.get())
            self.update_state()
            if self.command:
                self.command()
    
    def update_state(self):
        if self.variable and self.variable.get():
            self.itemconfigure(self.checkmark, state="normal")
        else:
            self.itemconfigure(self.checkmark, state="hidden")

